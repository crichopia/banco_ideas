<?php
echo "El servidor PHP funciona correctamente";
?>