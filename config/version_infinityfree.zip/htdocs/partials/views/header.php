<style>
    header{
        display:                             grid;
        grid-template-columns:        1fr 6fr 1fr;
        place-items:                       center;
        color:                             #fff;
        font-family: sans-serif, Arial, Helvetica;
        gap:                                 10px;
        margin:                                 0;
        max-width:                           100%;
        min-height:                         80px;
        background-color:               #463477;
        border-bottom:        #9254b8 solid 2px;
        padding-left:                          0;
    	margin-bottom:10px;

        @media (max-width: 800px) {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr;
        gap:                                 5px;
		text-align: center;
        }
        }

 	h1{
    	margin:                             0;
		@media (max-width:800px){
            
        }
    }
    #logo{
        height: 80px;
        width: 80px;
		@media (max-width:800px){
        height: 50px;
        width: 50px;        }
    }

    #logout{
        color:               #fff;
        border:                none;
        border-radius:         10px;
        background-color: #8e6ac4;
        font-size:             20px;
        padding:           5px 10px;
        cursor:             pointer;
        @media (max-width: 800px) {
            font-size:			16px;
        }
    }

</style>

<header class="header">
    <img id="logo" src="/img/logo.png" alt="logo">
    <h1 ><span>Crichopian Tools</span></h1>

    <?php if(isset($_SESSION['username'])){
        
    } ?>
    <?php if (isset($_SESSION['username'])) {?>
        <button id="logout" onclick="window.location.href='/controllers/logout.php'">Logout</button>
    <?php } ?>

</header>