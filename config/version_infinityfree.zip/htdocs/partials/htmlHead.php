<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='icon' href='../favico.ico' type='image/x-icon' sizes="16x16" />
    <script src="https://kit.fontawesome.com/94200745bb.js" crossorigin="anonymous"></script>
    <style>
body{
    background-image: linear-gradient(#463477, #9559b1);
    background-size: 100% 100%;
    color:                             #fff;
    font-family: sans-serif, Arial, Helvetica;
    display:                             flex;
    flex-direction:                    column;
    box-sizing:                    border-box;
    margin:                                 0;
    height:                            100dvh;
    
}

.centerTheDamnButton{
    display:                             flex;
    place-items:                       center;
    justify-content:                   center;
}

/* cards */
.cardContainer{
    padding-top:15px;
    display:                             flex;
    flex-direction:                    column;
    place-items:                       center;
    justify-content:                   center;
    width:                              100%;
    max-height:                             70vh;
    @media (max-width: 800px) {
        margin-top:10px;
    }
}

.card{
    display:                             flex;
    flex-direction:                    column;
    place-items:                       center;
    width:                              55dvw;
    border:               #9254b8 solid 2px;
    background-color:               #8e6ac4;
    border-radius:                       25px;
    padding-top:                       40px;
    @media (max-width: 800px) {
    width:                              55dvw;
    }
    }

}
.card h1{
    margin:                                 0;
    margin-bottom:                        5px;
    padding:                                0;
}
.card h2{
    margin:                                 0;
    margin-bottom:                        5px;
}



    </style>
</head>
<body>
