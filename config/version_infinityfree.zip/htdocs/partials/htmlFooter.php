<script src="/jsScript.js"></script>

</body>
</html>
